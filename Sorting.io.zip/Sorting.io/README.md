# Sorting Visualization
### This is a simple visualization project made using javascript 
- Bubble Sort 
- Selection Sort
- Insertion Sort
- Quick Sort
- Merge Sort

### This is built using HTML, CSS, JavaScript <br/>

[Check out the website here](https://abhishekprakash5.github.io/Sorting-Visualization/)

<img src="img/img1.png"> <br/>
<img src="img/img2.png"> <br/>
<img src="img/img3.png"> <br/>
